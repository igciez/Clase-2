#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "cliente.h"



Cliente* cliente_newParametros(char* strId,char* name, char* lastName, char* email, char genero, char* profesion, char* usuario, char* nacionalidad)
{
    int id;
    Cliente* this;

    id = atoi(strId); //FALTA VALIDAR

    this = cliente_new();
    if( !cliente_setId(this,id) &&
        !cliente_setName(this,name) &&
        !cliente_setLastName(this,lastName) &&
        !cliente_setEmail(this,email) &&
        !cliente_setGenero(this,genero) &&
        !cliente_setProfesion(this,profesion) &&
        !cliente_setUsuario(this,usuario) &&
        !cliente_setNacionalidad(this,nacionalidad)
       )
    {
        return this;
    }
    cliente_delete(this);
    return NULL;
}


Cliente* cliente_new(void)
{

    Cliente* returnAux = (Cliente*) malloc(sizeof(Cliente));
    return returnAux;

}

void cliente_delete(Cliente* this)
{
    if(this != NULL)
        free(this);
}


int cliente_setId(Cliente* this, int id)
{
    static int ultimoId = -1;
    int retorno = -1;
    if(this != NULL && id == -1)
    {
        retorno = 0;
        ultimoId++;
        this->id = ultimoId;
    }
    else if(this != NULL && id > ultimoId)
    {
        retorno = 0;
        ultimoId = id;
        this->id = ultimoId;
    }
    return retorno;
}

int cliente_setName(Cliente* this, char* name)
{
    int retorno = -1;
    if(this != NULL && name != NULL /*&& isValidName(name)*/)
    {
        retorno = 0;
        strcpy(this->nombre,name);
    }
    return retorno;
}

int cliente_setLastName(Cliente* this, char* lastName)
{
    int retorno = -1;
    if(this != NULL && lastName != NULL /*&& isValidName(name)*/)
    {
        retorno = 0;
        strcpy(this->apellido,lastName);
    }
    return retorno;
}

int cliente_setEmail(Cliente* this, char* email)
{
    int retorno = -1;
    if(this != NULL && email != NULL /*&& isValidName(name)*/)
    {
        retorno = 0;
        strcpy(this->email,email);
    }
    return retorno;
}

int cliente_setGenero(Cliente* this, char genero)
{
    int retorno = -1;
    if(this != NULL /*&& isValidName(name)*/)
    {
        retorno = 0;
        this->genero = genero;
    }
    return retorno;
}

int cliente_setProfesion(Cliente* this, char* profesion)
{
    int retorno = -1;
    if(this != NULL && profesion != NULL /*&& isValidName(name)*/)
    {
        retorno = 0;
        strcpy(this->profesion,profesion);
    }
    return retorno;
}

int cliente_setUsuario(Cliente* this, char* usuario)
{
    int retorno = -1;
    if(this != NULL && usuario != NULL /*&& isValidName(name)*/)
    {
        retorno = 0;
        strcpy(this->usuario,usuario);
    }
    return retorno;
}

int cliente_setNacionalidad(Cliente* this, char* nacionalidad)
{
    int retorno = -1;
    if(this != NULL && nacionalidad != NULL /*&& isValidName(name)*/)
    {
        retorno = 0;
        strcpy(this->nacionalidad,nacionalidad);
    }
    return retorno;
}

int cliente_getName(Cliente* this, char* name)
{
    int retorno = -1;
    if(this != NULL && name != NULL)
    {
        retorno = 0;
        strcpy(name,this->nombre);
    }
    return retorno;
}

int cliente_getLastName(Cliente* this, char* lastName)
{
    int retorno = -1;
    if(this != NULL && lastName != NULL)
    {
        retorno = 0;
        strcpy(lastName,this->apellido);
    }
    return retorno;
}

int cliente_getEmail(Cliente* this, char* email)
{
    int retorno = -1;
    if(this != NULL && email != NULL)
    {
        retorno = 0;
        strcpy(email,this->email);
    }
    return retorno;
}

int cliente_getGenero(Cliente* this, char* genero)
{
    int retorno = -1;
    if(this != NULL && genero != NULL)
    {
        retorno = 0;
        *genero= this->genero;
    }
    return retorno;
}

int cliente_getProfesion(Cliente* this, char* profesion)
{
    int retorno = -1;
    if(this != NULL && profesion != NULL)
    {
        retorno = 0;
        strcpy(profesion,this->profesion);
    }
    return retorno;
}

int cliente_getUsuario(Cliente* this, char* usuario)
{
    int retorno = -1;
    if(this != NULL && usuario != NULL)
    {
        retorno = 0;
        strcpy(usuario,this->usuario);
    }
    return retorno;
}

int cliente_getNacionalidad(Cliente* this, char* nacionalidad)
{
    int retorno = -1;
    if(this != NULL && nacionalidad != NULL)
    {
        retorno = 0;
        strcpy(nacionalidad,this->nacionalidad);
    }
    return retorno;
}
int cliente_getId(Cliente* this, int* id)
{
    int retorno = -1;
    if(this != NULL && id != NULL)
    {
        retorno = 0;
        *id = this->id;
    }
    return retorno;
}

void cliente_print(Cliente* this)
{
    int id;
    char name[64];
    char lastName[64];
    char email[256];
    char genero;
    char profesion[256];
    char usuario[256];
    char nacionalidad[256];


    if(this != NULL)
    {
        cliente_getName(this,name);
        cliente_getLastName(this,lastName);
        cliente_getEmail(this,email);
        cliente_getGenero(this,&genero);
        cliente_getProfesion(this,profesion);
        cliente_getUsuario(this, usuario);
        cliente_getNacionalidad(this,nacionalidad);
        cliente_getId(this,&id);

        fprintf(stdout,"\nNombre: %s.\nApellido: %s.\nEmail: %s.\nGenero: %c.\nProfesion: %s.\nUsuario: %s.\nNacionalidad: %s.\nId: %d.\n",
                name,lastName,email,genero,profesion,usuario,nacionalidad,id);
    }
}

void cliente_listar (ArrayList* listaCliente)
{
    int i;

    for(i = 0;i < al_len (listaCliente); i++)
    {
        cliente_print(al_get(listaCliente,i));
    }
}
