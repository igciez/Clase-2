#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#include "ArrayList.h"

int parserEMovie(char* path , ArrayList* pArrayListEMovie);
