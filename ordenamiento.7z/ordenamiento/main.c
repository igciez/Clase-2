/*  data [j+1]=data [j];
    data [j]= data [j+1]; se prueba los distintos desplazamientos con j++ y con j--; !!hacer con print!!
    data [j-1]=data[j];
    data [j]= data [j-1];
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
  int array [10]={1,6,9,15,13,69,1,8,9,19}, i ,j, temp;

  for (i=1;i<10;i++)
  {
      temp=array[i];
      j=i-1;
      while(j>=0 && temp<array[j])
      {
          array[j+1]=array[j];
          j--;

      }
    array[j+1]=temp; //insercion

  }

    for(i=0;i<10;i++)
    {
        printf("%d,",array[i]);
    }

    return 0;
}
