#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED
typedef struct
{
    int id;
    char nombre[128];
    int horasTrabajadas;
    int sueldo;
}EEmpleado;

EEmpleado* Empleado_new();
EEmpleado* Empleado_newParametros(char* strId, char* nombre, char* strHorasTrabajadas);
void Empleado_delete();

int Empleado_setId(EEmpleado* this,int id);
int Empleado_getId(EEmpleado* this,int* id);

int Empleado_setNombre(EEmpleado* this,char* nombre);
int Empleado_getNombre(EEmpleado* this,char* nombre);

int Empleado_setHorasTrabajadas(EEmpleado* this,int horasTrabajadas);
int Empleado_getHorasTrabajadas(EEmpleado* this,int* horasTrabajadas);

int Empleado_setSueldo(EEmpleado* this,int sueldo);
int Empleado_getSueldo(EEmpleado* this,int* sueldo);

#endif // EMPLEADO_H_INCLUDED
