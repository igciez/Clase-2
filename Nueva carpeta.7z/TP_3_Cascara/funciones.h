#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED


typedef struct{

    char titulo[20];
    char genero[20];
    int duracion;
    char descripcion[50];
    int puntaje;
    char linkImagen[50];
    int id;
    int isEmpty;

}Movie;


/**
 *  Agrega una pelicula al archivo binario
 *  @param movie la estructura a ser agregada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo agregar la pelicula o no
 */
int agregarPelicula(EMovie movie);

/**
 *  Borra una pelicula del archivo binario
 *  @param movie la estructura a ser eliminada al archivo
 *  @return retorna 1 o 0 de acuerdo a si pudo eliminar la pelicula o no
 */
int borrarPelicula(EMovie movie);

/**
 *  Genera un archivo html a partir de las peliculas cargadas en el archivo binario.
 *  @param lista la lista de peliculas a ser agregadas en el archivo.
 *  @param nombre el nombre para el archivo.
 */
void generarPagina(EMovie lista[], char nombre[]);

Movie* movie_new(void);
void movie_delete(Movie* this);
int movie_setId(Movie* this, int id);
int movie_setIsEmpty(Movie* this, int isEmpty);
int movie_setTitulo(Movie* this, char* titulo);
int movie_setGenero(Movie* this, char* genero);
int movie_setDescripcion(Movie* this, char* descripcion);
int movie_setDuracion(Movie* this, int duracion);
int movie_setPuntaje(Movie* this, int puntaje);
int movie_setLinkImagenn(Movie* this, char* linkImagen);
int movie_getLinkImagenn(Movie* this, char* linkImagen);
int movie_getId(Movie* this, int* id);
int movie_getIsEmpty(Movie* this, int* isEmpty);
int movie_getTitulo(Movie* this, char* titulo);
int movie_getGenero(Movie* this, char* genero);
int movie_getDescripcion(Movie* this, char* descripcion);
int movie_getPuntaje(Movie* this, int* puntaje);
int movie_getDuracion(Movie* this, int* duracion);

#endif // FUNCIONES_H_INCLUDED
