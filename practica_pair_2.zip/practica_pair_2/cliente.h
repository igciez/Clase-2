#ifndef _CLIENTE_H
#define _CLIENTE_H
struct
{
    char nombre[64];
    char apellido[64];
    char email[256];
    char genero;
    char profesion[256];
    char usuario[256];
    char nacionalidad[256];
    int id;
}typedef Cliente;

Cliente* cliente_newParametros(char* strId,char* name, char* lastName, char* email, char genero, char* profesion, char* usuario, char* nacionalidad);
Cliente* cliente_new(void);
void cliente_delete(Cliente* this);
int cliente_setId(Cliente* this, int id);
int cliente_setName(Cliente* this, char* name);
int cliente_setLastName(Cliente* this, char* lastName);
int cliente_setEmail(Cliente* this, char* email);
int cliente_setGenero(Cliente* this, char genero);
int cliente_setProfesion(Cliente* this, char* profesion);
int cliente_setUsuario(Cliente* this, char* usuario);
int cliente_setNacionalidad(Cliente* this, char* nacionalidad);
int cliente_getName(Cliente* this, char* name);
int cliente_getEmail(Cliente* this, char* email);
int cliente_getGenero(Cliente* this, char* genero);
int cliente_getProfesion(Cliente* this, char* profesion);
int cliente_getUsuario(Cliente* this, char* usuario);
int cliente_getNacionalidad(Cliente* this, char* nacionalidad);
int cliente_getId(Cliente* this, int* id);
void cliente_print(Cliente* this);
void cliente_listar (ArrayList* listaCliente);

#endif // _CLIENTE_H

