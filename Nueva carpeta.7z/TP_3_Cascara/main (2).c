#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
#include "funciones.c"

int main()
{
    char seguir='s';
    int opcion=0;

    /*int cantidadDePeliculas = 30;

    EMovie peliculas[cantidadDePeliculas];

    int i;
    for(i=0; i<cantidadDePeliculas; i++)
    {
        peliculas[i].estado = 0;
    }*/

    /*struct ALFA
    {unsigned int a;
    float b;
    int* c;
    };
    struct ALFA* d;
    if((d=(struct ALFA*)malloc(sizeof(struct ALFA)))==NULL)
        exit(0);*/

    while(seguir=='s')
    {
        printf("1- Agregar pelicula\n");
        printf("2- Borrar pelicula\n");
        printf("3- Generar pagina web\n");
        printf("4- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                agregarPelicula();
                break;
            case 2:
                break;
            case 3:
               break;
            case 4:
                seguir = 'n';
                break;
        }
    }
    return 0;
}
