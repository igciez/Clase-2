#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED


typedef struct{
    char titulo[20];
    char genero[20];
    int duracion;
    char descripcion[50];
    int puntaje;
    char linkImagen[50];
    int estado;
}EMovie;


/**
 *  Agrega una pelicula al archivo binario
 */
void agregarPelicula();

/**
 *  Borra una pelicula del archivo binario
 */
void borrarPelicula();

/**
 *  Genera un archivo html a partir de las peliculas cargadas en el archivo binario.
 *  @param lista la lista de peliculas a ser agregadas en el archivo.
 *  @param nombre el nombre para el archivo.
 */
void generarPagina(EMovie[], char[]);

/**
 * Obtiene el índice del primer espacio libre del vector EPersona.
 * @param Recibe el vector de la estructura.
 * @param Recibe la longitud del vector.
 * @return Retorna el índice del primer espacio libre del vector, retorna -1 si no hay espacio disponible.
 */
int obtenerEspacioDisponible(EMovie[], int);

/**
 * Examina el estado de la estructura recibida.
 * @param Recibe el vector de la estructura.
 * @param Recibe la longitud del vector.
 * @return Retorna el número que corresponde al estado de la estructura. Es 0 si está vacía, 1 si hay por lo menos 1 elemento agregado y 2 si el vector está lleno.
 */
int estadoDeLaEstructuraPelicula(EMovie[], int);
/**
 * Pide que se ingrese la edad y la verifica. No sale de la función hasta que se haya ingresado un número válido.
 * @return Retorna el número validado.
 */
int ingresarPuntajeDeLaPelicula();
/**
 * Pide que se ingrese el DNI y lo verifica. No sale de la función hasta que se haya ingresado un número válido.
 * @return Retorna el número validado.
 */
int ingresarDuracionDeLaPelicula();
/**
 * Pide que se ingrese el DNI y lo verifica. No sale de la función hasta que se haya ingresado un número válido.
 * @param Recibe el vector de la estructura.
 * @param Recibe el vector de la estructura.
 * @return Retorna el número validado.
 */
int buscarPeliculaPorTitulo(char[], char[]);
/**
 * Pide que se ingrese el DNI y lo verifica. No sale de la función hasta que se haya ingresado un número válido.
 * @param Recibe el vector de la estructura.
 * @return Retorna el número validado.
 */
int guardarPeliculaEnArchivo(char[], char[], char[], char[], int, int, int);
#endif // FUNCIONES_H_INCLUDED
