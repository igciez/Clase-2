#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

int esSoloLetras(char array[]);
int esNumeroChar (char num[]);
int esAlfaNumerico(char str[]);
int esTelefono(char str[]);
void rangoEdad (char input[]);
void cualquierTeclaContinnuar(void);
int maximo(int maximo, int valor);
int introducirContrasenia(char* truePass, char* pasword);
