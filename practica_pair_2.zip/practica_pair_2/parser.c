#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "cliente.h"


int parserEmployee(char* path , ArrayList* pArrayListEmployee)
{
    int retorno = -1;
    char bId[4096];
    char bName[4096];
    char bLastName[4096];
    char bEmail[4096];
    char bGenero;
    char bProfesion[4096];
    char bUsuario[4096];
    char bNacionalidad[4096];
    Cliente* auxiliarCliente;

    FILE* pFile;
    pFile = fopen(path,"r");

    if(pFile != NULL)
    {
        retorno = 0;
        fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%c,%[^,],%[^,],%[^\n]\n",bId,bName,bLastName,bEmail,&bGenero,bProfesion,bUsuario,bNacionalidad);
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%c,%[^,],%[^,],%[^\n]\n",bId,bName,bLastName,bEmail,&bGenero,bProfesion,bUsuario,bNacionalidad);
            auxiliarCliente = cliente_newParametros(bId,bName,bLastName,bEmail,bGenero,bProfesion,bUsuario,bNacionalidad);
            al_add(pArrayListEmployee,auxiliarCliente);
        }
    }

    return retorno;
}

