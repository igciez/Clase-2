#ifndef FANTASMA_H_INCLUDED
#define FANTASMA_H_INCLUDED
typedef struct
{
    char nombre[50];
    //------------
    int idFantasma;
    int isEmpty;
}Fantasma;



int fantasma_init(Fantasma* array,int limite);
int fantasma_mostrar(Fantasma* array,int limite);
int fantasma_mostrarDebug(Fantasma* array,int limite);
int fantasma_alta(Fantasma* array,int limite);
int fantasma_baja(Fantasma* array,int limite, int id);
int fantasma_modificacion(Fantasma* array,int limite, int id);
int fantasma_ordenar(Fantasma* array,int limite, int orden);
//int buscarLugarLibre(Fantasma* array,int limite);
//int proximoId();


int pantalla_altaForzada(Pantalla* array,int limite,char* nombre,char* direccion, float precio, int tipo)
int cont_altaForzada(Contratacion* arrayC,int limite,Pantalla* pantallas, int lenPantallas, int idPantalla,char* archivo,char* cuit,int dias);


int informar_ConsultaFacturacion(Contratacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas, char* cuit);
int informar_ListarContrataciones(Contratacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas);
int informar_ListarCantidadContratacionesImporte(Contratacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas);


#endif // FANTASMA_H_INCLUDED
