void startTesting(int testGroup);
