#include "Empleado.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

EEmpleado* Empleado_new()
{
    EEmpleado* this;
    this=malloc(sizeof(EEmpleado));
    return this;
}

EEmpleado* Empleado_newParametros(char* strId, char* nombre, char* strHorasTrabajadas)

{
    int id;
    int horasTrabajadas;
    EEmpleado* this;
    id = atoi(strId);
    horasTrabajadas= atoi(strHorasTrabajadas);
    this = Empleado_new();
    if(!Empleado_setId(this, id) &&
       !Empleado_setNombre(this, nombre) &&
       !Empleado_setHorasTrabajadas(this, horasTrabajadas))
    {
        return this;
    }
    Empleado_delete(this);
    return NULL;
}

void Empleado_delete(EEmpleado* this)
{
    free(this);
}

int Empleado_setId(EEmpleado* this,int id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->id=id;
        retorno=0;
    }
    return retorno;
}

int Empleado_getId(EEmpleado* this,int* id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *id=this->id;
        retorno=0;
    }
    return retorno;
}

int Empleado_setNombre(EEmpleado* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int Empleado_getNombre(EEmpleado* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int Empleado_setHorasTrabajadas(EEmpleado* this,int horasTrabajadas)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->horasTrabajadas=horasTrabajadas;
        retorno=0;
    }
    return retorno;
}

int Empleado_getHorasTrabajadas(EEmpleado* this,int* horasTrabajadas)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *horasTrabajadas=this->horasTrabajadas;
        retorno=0;
    }
    return retorno;
}

int Empleado_setSueldo(EEmpleado* this,int sueldo)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->sueldo=sueldo;
        retorno=0;
    }
    return retorno;
}

int Empleado_getSueldo(EEmpleado* this,int* sueldo)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *sueldo=this->sueldo;
        retorno=0;
    }
    return retorno;
}

