#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    /*char palabra []="hola mundo";
    char str[25],copia;
    */
    char array1[5];
    char array2[5];
    //printf("%s",palabra);

   /* int i;
    int len= strlen(palabra); //esta afuera del fot para asegurar que se imprima una sola vez y no las que diga el for.
    for(i=0;i<len;i++)
    {
        printf("%c",palabra[i]);

    }
    */
    printf("%s",array2);

    //scanf("%s",array1);---- esta no se usa, se cambia por fgets();
    fgets(array1,sizeof(array1),stdin);


    strcpy(array2,array1);

    printf("%s",array2);

    return 0;
}
