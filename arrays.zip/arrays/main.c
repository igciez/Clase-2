//5  numeros al usuario
//sacar el promedio
//array 1) pedir numer y guardar
//2) recorrer array y promediar.
#include <stdio.h>
#include <stdlib.h>
#define MAX 5

//float calcularPromedio (int valores[],int cantidad);
int calcularPromedio(int valores[],int cantidad, float *resultado);
int maximo (int valores [], int cantidad, float *resultado);


int main()
{
    int numero[MAX],i,maximo,minimo;
    float promedio;


    for(i=0;i<MAX;i++){


        printf("Ingrese el %i numero:\n",i+1);
        scanf("%d",&numero[i]);

    }

        if(i==0){
            maximo=numero[i];
            minimo=numero[i];
        }
        else{
            if(numero[i]>maximo){
                maximo=numero[i];
            }
            else if(numero [i]<minimo){
                minimo=numero[i];
            }
        }


    //promedio=calcularPromedio(numero, MAX);
    if (calcularPromedio(numero,MAX,&promedio)==0){
        printf("\n\nEl promedio es:%.2f\n\n",promedio);
    }
    else {
        printf("Error, de datos en el array.")
    }
    printf("El numero maximo es:%d\n\n",maximo);
    return 0;
}

/*float calcularPromedio (int valores[],int cantidad){
    float promedio;
    int i,aux=0;
    for(i=0;i<cantidad;i++){
        aux+=valores[i];
    }
    promedio=(float)aux/cantidad;

    return promedio;
}
*/
int calcularPromedio(int valores[],int cantidad, float *resultado){
    float promedio;
    int i,aux=0,retorno;

    if (cantidad==0) /*|| resultado== NULL)*/  {
        retorno=-1;
    }
    else {
        retorno=0;
    }
    for(i=0;i<cantidad;i++){
        aux+=valores[i];
    }
    *resultado=(float)aux/cantidad;
    return retorno;
}
int maximo (int valores [], int cantidad, float *resultado){

 for (int)
    if(i==0){
        maximo=numero[i];
    }
    else if(numero[i]>maximo){
        maximo=numero[i];
            }



}
