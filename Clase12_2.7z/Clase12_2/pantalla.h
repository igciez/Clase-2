#ifndef PANTALLA_H_INCLUDED
#define PANTALLA_H_INCLUDED


typedef struct
{
    char nombre[50];
    char direccion[50];
    float precio;
    int tipo;
    //------------
    int idPantalla;
    int isEmpty;
}Pantalla;

#include "Contratacion.h"

int pantalla_init(Pantalla* array,int limite);
int pantalla_mostrar(Pantalla* array,int limite);
int pantalla_mostrarDebug(Pantalla* array,int limite);
int pantalla_alta(Pantalla* array,int limite);
int pantalla_baja(Pantalla* array,int limite, int id);
int pantalla_modificacion(Pantalla* array,int limite, int id);
int pantalla_ordenar(Pantalla* array,int limite, int orden);
int pantalla_buscarPorId(Pantalla* array,int limite, int id);
int pantalla_altaForzada(Pantalla* array,int limite,char* nombre,char* direccion, float precio, int tipo);

//int pantalla_cantidad(Pantalla* array,int limite, float *acumuladorPrecio, int *acumuladorPantalla);
int pantalla_acumuladorPantalla(Pantalla* array,int limite);
float pantalla_acumuladorPrecio(Pantalla* array,int limite);
int pantalla_mostrarSuperaPromedio(Pantalla* array,int limite, float* promedio);
int pantalla_mostrarNoSuperaPromedio(Pantalla* array,int limite, float* promedio);
int pantalla_PantallaMasDeUnaPublicacion(Contratacion* arrayC, int limiteC, Pantalla* arrayP, int limiteP);
int pantalla_facturacion(Contratacion* arrayC, int limiteC, Pantalla* arrayP, int limiteP);
int pantalla_Mayorfacturacion(Contratacion* arrayC, int limiteC, Pantalla* arrayP, int limiteP);
int pantalla_MayorContratacion(Contratacion* arrayC, int limiteC, Pantalla* arrayP, int limiteP);
int pantalla_ContratacionMasCostosa(Contratacion* arrayC, int limiteC, Pantalla* arrayP, int limiteP);
//int buscarLugarLibre(Pantalla* array,int limite);
//int proximoId();
//int pantalla_buscarPorId(Pantalla* array,int limite, int id);
#endif // PANTALLA_H_INCLUDED
