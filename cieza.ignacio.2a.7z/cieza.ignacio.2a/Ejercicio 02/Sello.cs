﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    class Sello
    {
        public static String mensaje; //atributo
        public static ConsoleColor color; //atributo

        public static String Imprimir() //metodo 
        {
            return Sello.mensaje;
        }
        public static void Borrar()
        {
            Sello.mensaje = "";
        }
        public static void ImprimirEnColor()
        {
            Console.ForegroundColor = Sello.color;
            Console.Write(Sello.Imprimir());
            Console.ForegroundColor= ConsoleColor.White;
        }




    }
}
