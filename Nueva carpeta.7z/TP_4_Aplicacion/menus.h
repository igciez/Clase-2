#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "ArrayList.h"
#include "carga.h"
#include "UsuarioVentaProductos.h"
void menuPrincipalMercadoLibre(ArrayList* lista_Usuarios, ArrayList* lista_Productos,ArrayList* productos_Destacados);
void printMenu(void);
void menuListasOrdenadas(ArrayList* lista_Usuarios,E_Listas_Ordenadas* listasOrdenadas);
