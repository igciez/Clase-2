#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int i, retorno=-1, numero;
    char array[25];

    fgets(array,sizeof(array),stdin);

    for(i=0;i<strlen(array);i++)
     {
         if(array[i]>='0'&&array[i]<='9')
         {
             retorno=0;
             break;
         }

     }
    if(retorno==0)
    {
        numero = atoi(array); // atoi, convierte de array a enteros
        printf("Valores ingresados son numeros");
    }
    else
    {
        printf("Valores ingesados, son incorrectos");
    }

    return 0;
}


