#ifndef PUBLICACION_H_INCLUDED
#define PUBLICACION_H_INCLUDED

typedef struct
{
    int idCliente;
    int rubro;
    char textoAviso[64];
    int estadoActivo;
    //------------
    int idPublicacion;
    int isEmpty;
}Publicacion;

#include "Cliente.h"

int publicacion_init(Publicacion* array,int limite);
int publicacion_mostrar(Publicacion* array,int limite, int id);
int publicacion_soloMostrar(Publicacion* array,int limite);
int publicacion_alta(Publicacion* arrayP,int limiteP, Cliente* arrayC, int limiteC);
int publicacion_altaForzada(Publicacion* arrayP,int limiteP, Cliente* arrayC, int limiteC, char* texto, int rubro, int idCliente, int estado);
int publicacion_baja(Publicacion* array,int limite, int id);
int publicacion_modificacionActiva(Publicacion* array,int limite, int id);
int publicacion_modificacionPausada(Publicacion* array,int limite, int id);
int publicacion_soloMostrarActivos(Publicacion* array,int limite, Cliente* arrayC, int limiteC);
int publicacion_informar (Publicacion* array, int limite, int rubro);
int publicacion_ordenar(Publicacion* array,int limite, int orden);

#endif // PANTALLA_H_INCLUDED


