#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXCAR 100

/*  1)definir un tipo de dato que represnete un producto. el producto tiene un nombre una descripcion y un precio.
    2)definir un array de 200 productos, indicar de alguna manera que la info de cada item no esta cargada.
    3)realizar una funcion que reciba el array, un indice y le permita al usuario cargar los datos en el item de la posicion especificada por el usuario.
    4)realizar una funcion que reciba el array y un indice e imprima los datos del item de la posicion especifica por el indice.
    5)



*/


typedef struct //va en .h (como los prototipos de funciones).
{
    int flagVacio;
    float precio;
    char nombre[MAXCAR];
    char descripcion[MAXCAR];

}Producto;

int cargarProducto (Producto nombre[], );

int main()
{
    int i;

    Producto productos [200];

    for(i=0;i<200;i++)
    {
      productos[i].flagVacio=1;
    }

    cargarProducto(Producto[0]);

    return 0;
}

int cargarProducto (Producto[] nombre)
{
    int i;

    for(i=0;i<200;i++)
    {
        printf("\nIngrese el nombre del producto: ");
        gets(nombre[i]);
        fflush(stdin);
        printf("\nIngrese la descripcion del producto: ");
        gets(descripcion[i]);
        fflush(stdin);
        printf("\nIngrese el precio del producto: ");
        scanf("%f",precio[i]);
        flag=0;
    }
}
