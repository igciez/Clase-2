int esSoloLetras(char array[]);
int esNumeroChar (char num[]);
int esAlfaNumerico(char str[]);
int esTelefono(char str[]);
void rangoEdad (char input[]);
void cualquierTeclaContinnuar(void);

