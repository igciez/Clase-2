#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"

//static int isValidName(char* name); //hacer valid general para char: titulo y genero// otro para descripcion.
//static int isValidLastName(char* lastName);
//static int isValidIsEmpty(int isEmpty);
static int isValidString(char errorMessage[], char errorMessageLenght[],char input[], int maxLenght,int attemps);
static int isValidInt(char errorMessage[], int* input,int lowLimit, int hiLimit,int attemps);
static int esAlfaNumerico(char str[]);
//-------FUNCIONES------------//

int agregarPelicula(EMovie movie)
{


}
//--------NEW-Y-DELETE-------------//

Movie* movie_new(void)
{
    Movie* returnAux = (Movie*) malloc(sizeof(Movie));
    return returnAux;\
}

void movie_delete(Movie* this)
{
    if(this != NULL)
        free(this);
}

//-----------SET------------//

int movie_setId(Movie* this, int id)
{
    static int ultimoId = -1;
    int retorno = -1;
    if(this != NULL && id == -1)
    {
        retorno = 0;
        ultimoId++;
        this->id = ultimoId;
    }
    else if(this != NULL && id > ultimoId)
    {
        retorno = 0;
        ultimoId = id;
        this->id = ultimoId;
    }
    return retorno;
}

int movie_setIsEmpty(Movie* this, int isEmpty)
{
    int retorno = -1;
    if(this != NULL && !isValidInt("\nError en el isEmpty.\n",isEmpty,0,1,2))
    {
        retorno = 0;
        this->isEmpty = isEmpty ;
    }
    return retorno;
}

int movie_setTitulo(Movie* this, char* titulo)
{
    int retorno = -1;
    if(this != NULL && titulo != NULL && esAlfaNumerico(titulo))
    {
        retorno = 0;
        strcpy(this->titulo,titulo);
    }
    return retorno;
}

int movie_setGenero(Movie* this, char* genero)
{
    int retorno = -1;
    if(this != NULL && genero != NULL && !isValidString("\nIngrese solo letras.\n","\nSe supero el maximo de letras permitido",genero,20,2))
    {
        retorno = 0;
        strcpy(this->genero,genero);
    }
    return retorno;
}

int movie_setDescripcion(Movie* this, char* descripcion)
{
    int retorno = -1;
    if(this != NULL && descripcion != NULL && !isValidString("\nIngrese solo letras.\n","\nSe supero el maximo de letras permitido",descripcion,50,2))
    {
        retorno = 0;
        strcpy(this->descripcion,descripcion);
    }
    return retorno;
}

int movie_setDuracion(Movie* this, int duracion)//? va el * en el int?
{
    int retorno = -1;
    if(this != NULL && !isValidInt("\nIngrese solo numeros enteros entre 1 y 500.\n",duracion,1,500,2))
    {
        retorno = 0;
        this->duracion = duracion ;
    }
    return retorno;
}

int movie_setPuntaje(Movie* this, int puntaje)//? va el * en el int?
{
    int retorno = -1;
    if(this != NULL && !isValidInt("\nIngrese solo numeros enteros entre 0 y 100.\n",puntaje,0,100,2)
    {
        retorno = 0;
        this->puntaje = puntaje ;
    }
    return retorno;
}

int movie_setLinkImagenn(Movie* this, char* linkImagen)//Resolver
{
    int retorno = -1;
    if(this != NULL && descripcion != NULL && isValidLastName(descripcion))// hacer un valid general para
    {
        retorno = 0;
        strcpy(this->descripcion,descripcion);
    }
    return retorno;
}
//----------GET---------//

int movie_getLinkImagenn(Movie* this, char* linkImagen)//Resolver
{

    return retorno;
}

int movie_getId(Movie* this, int* id)
{
    int retorno = -1;
    if(this != NULL && id != NULL)
    {
        retorno = 0;
        *id = this->id;
    }
    return retorno;
}

int movie_getIsEmpty(Movie* this, int* isEmpty)
{
    int retorno = -1;
    if(this != NULL && isEmpty != NULL)
    {
        retorno = 0;
        *isEmpty = this->isEmpty;
    }
    return retorno;
}

int movie_getTitulo(Movie* this, char* titulo)
{
    int retorno = -1;
    if(this != NULL && titulo != NULL)
    {
        retorno = 0;
        strcpy(titulo,this->titulo);
    }
    return retorno;
}

int movie_getGenero(Movie* this, char* genero)
{
    int retorno = -1;
    if(this != NULL && genero != NULL)
    {
        retorno = 0;
        strcpy(genero,this->genero);
    }
    return retorno;
}

int movie_getDescripcion(Movie* this, char* descripcion)
{
    int retorno = -1;
    if(this != NULL && descripcion != NULL)
    {
        retorno = 0;
        strcpy(descripcion,this->descripcion);
    }
    return retorno;
}

int movie_getPuntaje(Movie* this, int* puntaje)
{
    int retorno = -1;
    if(this != NULL && puntaje != NULL)
    {
        retorno = 0;
        *puntaje = this->puntaje;
    }
    return retorno;
}

int movie_getDuracion(Movie* this, int* duracion)
{
    int retorno = -1;
    if(this != NULL && duracion != NULL)
    {
        retorno = 0;
        *duracion = this->duracion;
    }
    return retorno;
}

//--------STATIC----------//

/*static int isValidName(char* name)
{
    return 1;
}

static int isValidLastName(char* lastName)
{
    return 1;
}

static int isValidIsEmpty(int isEmpty)
{
    return 1;
}
*/
/**
 * \brief Solicita un string
 * \param requestMessage Es el mensaje a ser mostrado para solicitar el dato
 * \param errorMessage Es el mensaje a ser mostrado en caso de error de tipo
 * \param errorMessageLenght Es el mensaje a ser mostrado en caso de error de longitud
 * \param input Array donde se cargar� el texto ingresado
 * \param maxLenght int Longitud maxima del texto ingresado
 * \param attemps indica la cantidad de reintentos ante un error
 * \return 0 si consiguio el String -1 si no
 *
 */
static int isValidString(char errorMessage[], char errorMessageLenght[],char input[], int maxLenght,int attemps)
{
    static int StringLetras(char input[]);
    int i;
    int retorno=-1;
    char buffer[1024];

    for(i=0;i<attemps;i++)
    {
        if (!StringLetras(buffer))
        {
            printf ("%s",errorMessage);
            continue;
        }
        if(strlen(buffer) >= maxLenght)
        {
            printf ("%s",errorMessageLenght);
            continue;
        }
        retorno=0;
        strcpy(input,buffer);
        break;
    }
    return retorno;
}

/**
 * \brief Obtiene un char ingresado.
 * \param input Array donde se cargar� el texto ingresado
 * \return 1 si el texto contiene solo letras
 */
static int StringLetras(char input[])
{
    static int esSoloLetras(char str[]);
    char aux[256];

    if(esSoloLetras(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}
/**
 * \brief Verifica si el valor recibido contiene solo letras
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo ' ' y letras y 0 si no lo es
 *
 */
static int esSoloLetras(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z'))
           return 0;
       i++;
   }
   return 1;
}

/**
 * \brief Solicita un numero entero al usuario y lo valida
 * \param requestMessage Es el mensaje a ser mostrado para solicitar el dato
 * \param errorMessage Es el mensaje a ser mostrado en caso de error
 * \param lowLimit Es el limite inferior aceptado
 * \param lowLimit Es el limite superior aceptado
 * \param input puntero al lugar donde se cargar� el numero ingresado
 * \param attemps indica la cantidad de reintentos ante un error
 * \return 0 si consiguio el Numero -1 si no
 *
 */
static int isValidInt(char errorMessage[], int* input,int lowLimit, int hiLimit,int attemps)
{
    static int StringNumeros(char input[]);
    char auxStr[256];
    int auxInt, i, retorno = -1;

    for(i=0;i<attemps;i++)
    {
        if (!getStringNumeros(auxStr))
        {
            printf ("%s",errorMessage);
            break;
            continue;

        }
        auxInt = atoi(auxStr);
        if(auxInt < lowLimit || auxInt > hiLimit)
        {
            printf ("%s",errorMessage);
            continue;

        }
        *input = auxInt;
        retorno = 0;
        break;

    }
    return retorno;
}

/**
 * \brief Solicita un texto num�rico al usuario y lo devuelve
 * \param mensaje Es el mensaje a ser mostrado
 * \param input Array donde se cargar� el texto ingresado
 * \return 1 si el texto contiene solo n�meros
 */
static int StringNumeros(char input[])
{
    static int esNumerico(char str[]);
    char aux[256];

    if(esNumerico(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

/**
 * \brief Verifica si el valor recibido es num�rico
 * \param str Array con la cadena a ser analizada
 * \return 1 si es n�merico y 0 si no lo es
 *
 */

static int esNumerico(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if (i == 0 && str[i] == '-')
       {
           i++;
           continue;

       }
       if(str[i] < '0' || str[i] > '9')
           return 0;

       i++;
   }
   return 1;
}

/**
 * \brief Verifica si el valor recibido contiene solo letras y n�meros
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo espacio o letras y n�meros, y 0 si no lo es
 *
 */
static int esAlfaNumerico(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && (str[i] < '0' || str[i] > '9'))
           return 0;
       i++;
   }
   return 1;
}

