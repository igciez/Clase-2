/*funciones.c
Autor: Marcelo Leonel Noguera
08/09/2017*/
#include "funciones.h"
void agregarPelicula()
{
    char titulo[20];
    char genero[20];
    char descripcion[50];
    char linkImagen[50];

    printf("Ingrese el titulo de la pelicula: ");
    //fflush(stdin);
    scanf("%s",&titulo);

    printf("Ingrese el genero de la pelicula: ");
    //fflush(stdin);
    scanf("%s",&genero);

    printf("Ingrese la descripcion de la pelicula: ");
    //fflush(stdin);
    scanf("%s",&descripcion);

    printf("Ingrese el link de la imagen de la pelicula: ");
    //fflush(stdin);
    scanf("%s",&linkImagen);

    int puntaje = ingresarPuntajeDeLaPelicula();
    int duracion = ingresarDuracionDeLaPelicula();

    if(buscarPeliculaPorTitulo(titulo, "peliculas.bin") == -1)
    {
        int estado = 1;
        guardarPeliculaEnArchivo(titulo, genero, descripcion, linkImagen, puntaje, duracion, estado);
    }
    else
    {
        printf("    Indice: %d", buscarPeliculaPorTitulo(titulo, "peliculas.bin"));
        printf("    Error: La pelicula ya est%c registrada con ese titulo\n", 160);
    }
}

void borrarPelicula()
{
    /*char titulo[20];

    printf("Ingrese el titulo de la pelicula a borrar: ");
    //fflush(stdin);
    scanf("%s",&titulo);

    if(buscarPeliculaPorTitulo(titulo, "peliculas.bin") == -1)
    {
        int estado = 1;
        guardarPeliculaEnArchivo(titulo, genero, descripcion, linkImagen, puntaje, duracion, estado);
    }
    else
    {
        printf("    Indice: %d", buscarPeliculaPorTitulo(titulo, "peliculas.bin"));
        printf("    Pelicula encontrada\n");
    }*/
}

int guardarPeliculaEnArchivo(char titulo[], char genero[], char descripcion[], char linkImagen[], int puntaje, int duracion, int estado)
{
    EMovie pelicula;
    strcpy(pelicula.titulo, titulo);
    strcpy(pelicula.genero, genero);
    strcpy(pelicula.descripcion, descripcion);
    strcpy(pelicula.linkImagen, linkImagen);
    pelicula.puntaje = puntaje;
    pelicula.duracion = duracion;
    pelicula.estado = estado;

    FILE * pArchivo;

    pArchivo = fopen("peliculas.bin","ab");

    fwrite(&pelicula,sizeof(EMovie),1,pArchivo);

    fclose(pArchivo);

    cambiarTamanio(1);
    /*archivo = fopen("peliculas.bin","rb");
    fread(&pelicula, sizeof(EMovie), 1, archivo);
    printf("%s--%s--%s--%s--%d--%d--%d\n", pelicula.titulo, pelicula.genero, pelicula.descripcion, pelicula.linkImagen, pelicula.puntaje, pelicula.duracion, pelicula.estado);
    fread(&pelicula, sizeof(EMovie), 1, archivo);
    fclose(archivo);
    printf("%s--%s--%s--%s--%d--%d--%d\n", pelicula.titulo, pelicula.genero, pelicula.descripcion, pelicula.linkImagen, pelicula.puntaje, pelicula.duracion, pelicula.estado);*/

    return 0;
}
void cambiarTamanio(int n)
{
    int cantidad = 0;
    FILE * pArchivo;

    pArchivo = fopen("peliculas.bin","rb");
    fread(&cantidad, sizeof(int), 1, pArchivo);    
    fclose(pArchivo);

    pArchivo = fopen("peliculas.bin","wb");
    cantidad = cantidad + n;
    fwrite(&cantidad,sizeof(EMovie),1,pArchivo);
    //fprintf(pArchivo,"%d", (cantidad + n));
    fclose(pArchivo);

    pArchivo = fopen("peliculas.bin","rb");
    fread(&cantidad, sizeof(int), 1, pArchivo);    
    fclose(pArchivo);

    printf("Cantidad: %d\n", cantidad);
}   
int obtenerEspacioDisponible(EMovie peliculas[], int cantidadDePeliculas)
{
    int indiceDelEspacioDisponible = 0;
    if(estadoDeLaEstructuraPelicula(peliculas, cantidadDePeliculas))
    {
        int i;
        for(i=0; i<cantidadDePeliculas; i++)
        {
            if(peliculas[i].estado == 0)
            {
                indiceDelEspacioDisponible = i;
                break;
            }
            else
            {
                indiceDelEspacioDisponible = -1;
            }
        }
    }
    return indiceDelEspacioDisponible;
}

int buscarPeliculaPorTitulo(char titulo[], char nombreDelArchivo[])
{
    int resultado = -1;
    int i = 0;

    int j = 0;

    FILE * pArchivo;
    EMovie pelicula;

    //fwrite(&pelicula,sizeof(EMovie),1,pArchivo);

    //printf("-----------------------------");

    if((pArchivo=fopen("peliculas.bin","rb"))==NULL)
    {
        printf("No se pudo abrir el archivo.");
        exit(1);
    }
    else
    {
        //fread(&pelicula, sizeof(EMovie), 1, pArchivo);
        while(!feof(pArchivo))
        {
            fread(&pelicula, sizeof(EMovie), 1, pArchivo);
            if(strcmp(pelicula.titulo, "") == 0)
            {
                break;
            }
            //printf("%s--%s\n", pelicula.titulo, titulo);

            if(strcmp(pelicula.titulo, titulo) == 0)
            {
                //printf("%s--%s--%s--%s--%d--%d--%d\n", pelicula.titulo, pelicula.genero, pelicula.descripcion, pelicula.linkImagen, pelicula.puntaje, pelicula.duracion, pelicula.estado);
                resultado = i;
                break;
            }
            fread(&pelicula, sizeof(EMovie), 1, pArchivo);
            i++;
            //break;
        }
    }
    fclose(pArchivo);

    /*pArchivo = fopen("peliculas.bin","rb");
    fread(&pelicula, sizeof(EMovie), 1, pArchivo);
    printf("%s--%s--%s--%s--%d--%d--%d\n", pelicula.titulo, pelicula.genero, pelicula.descripcion, pelicula.linkImagen, pelicula.puntaje, pelicula.duracion, pelicula.estado);
    fread(&pelicula, sizeof(EMovie), 1, pArchivo);
    fclose(pArchivo);
    printf("%s--%s--%s--%s--%d--%d--%d\n", pelicula.titulo, pelicula.genero, pelicula.descripcion, pelicula.linkImagen, pelicula.puntaje, pelicula.duracion, pelicula.estado);*/
    return resultado;
}

int estadoDeLaEstructuraPelicula(EMovie peliculas[], int cantidadDePeliculas)
{
    // 0 -- vacio , 1 -- alguno seteado, 2 -- lleno
    int estadoDeLaEstructura = 0;
    int contadorElementosSeteados = 0;
    int i;
    for(i=0; i<cantidadDePeliculas; i++)
    {
        if(peliculas[i].estado)
        {
            estadoDeLaEstructura = 1;
            contadorElementosSeteados++;
        }
        if(contadorElementosSeteados == cantidadDePeliculas)
        {
            estadoDeLaEstructura = 2;
        }
    }
    return estadoDeLaEstructura;
}

int ingresarPuntajeDeLaPelicula()
{
    int puntaje;
    char puntajeIngresado[4];
    int flag = 0;

    while(!flag)
    {
        printf("Ingrese el puntaje de la pelicula: ");
        fflush(stdin);
        scanf("%s",&puntajeIngresado);
        puntaje = atoi(puntajeIngresado);

        if(!(puntaje < 0))
        {
            flag = 1;
        }
        else
        {
            printf("    Error: N%cmero no v%clido.\n", 163, 160);
            flag = 0;
        }
    }
    return puntaje;
}

int ingresarDuracionDeLaPelicula()
{
    int duracion;
    char duracionIngresada[4];
    int flag = 0;

    while(!flag)
    {
        printf("Ingrese la duracion de la pelicula: ");
        fflush(stdin);
        scanf("%s",&duracionIngresada);
        duracion = atoi(duracionIngresada);

        if(!(duracion <= 0))
        {
            flag = 1;
        }
        else
        {
            printf("    Error: N%cmero no v%clido.\n", 163, 160);
            flag = 0;
        }
    }
    return duracion;
}
