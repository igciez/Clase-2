#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Cliente.h"
#include "utn.h"
#include "Publicacion.h"

#define DEFINE_DEL_ARCHIVO  "hola"

//Funciones privadas
static int proximoId(void);
static int buscarLugarLibre(Cliente* array,int limite);
//__________________



/** \brief inicializa la estructura Cliente.
 * \param array Cliente*, estructura a inicializar.
 * \param limite int, es la cantidad de estructuras a inicializar
 * \return int, retorna un entero.
 *
 */
int cliente_init(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}
/** \brief muestra los campos de la estructura cliente.
 *
 * \param Cliente* array, estructura a mostrar los campos.
 * \param limite, es la cantidad de estructuras a mostrar.
 * \return int, un entero.
 *
 */

int cliente_mostrar(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("\nNombre: %s. \nApellido: %s.\nCuit: %s\nID cliente: %d.\n\n",array[i].nombre, array[i].apellido, array[i].cuit, array[i].idCliente);
        }
    }
    return retorno;
}

/** \brief completa campo nombre, apellido, cuit, id y isEmpty de la estructura cliente.
 *
 * \param Cliente* array, estructura a completar.
 * \param limite, es la cantidad de estructuras a mostrar.
 * \return int, un entero.
 *
 */

int cliente_alta(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    char nombre[50];
    char apellido[50];
    char cuit[50];;

    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            if(!getValidString("\nNombre del Cliente: ","\nEso no es un nombre.\n","\nEl maximo es 40\n",nombre,40,2))
            {
                if(!getValidString("\nApellido del Cliente: ","\nApellido no valido.\n","\nEl maximo es 40\n",apellido,40,2))
                {
                  if (getStringNumeros("\nIngrese el Cuit del cliente (sin esapacio):  ",cuit))
                   {
                            retorno = 0;
                            strcpy(array[i].nombre,nombre);
                            strcpy(array[i].apellido,apellido);
                            strcpy(array[i].cuit,cuit);
                            array[i].idCliente = proximoId();
                            array[i].isEmpty = 0;
                   }

                }
            }
            else
            {
                retorno = -3;
            }
        }
        else
        {
            retorno = -2;
        }
    }
    return retorno;
}

/** \brief cambia el isEmpty cliente de 0 a 1.
 *
 * \param Cliente* array,
 * \param limite, cantidad de estructuras.
 * \param id, valor ingresado por usuario para ser comparado con las estructuras.
 * \return int, un valor entero.
 *
 */

int cliente_baja(Cliente* array,int limite, int id)
{
    int indiceAEliminar;
    int retorno=-1;
    indiceAEliminar = cliente_buscarPorId(array,limite,id);
    if(indiceAEliminar>=0)
    {
        array[indiceAEliminar].isEmpty=1;
        retorno=0;
    }
    return retorno;
}



/** \brief modifica los campos de la estructura cliente.
 *
 * \param Cliente* array, estructura a modificar.
 * \param limite, cantidad de estructuras a modificar.
 * \param id, valor ingresado por usuario para ser comparado con las estructuras.
 * \return int, valor entero.
 *
 */

int cliente_modificacion(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int indiceAModificar;
    char nombre[50];
    char apellido[50];
    char cuit[50];

    indiceAModificar = cliente_buscarPorId(array,limite,id);
    if(indiceAModificar>=0 && !array[indiceAModificar].isEmpty)
    {
        if(!getValidString("\nIngrese el nombre: ","\nEso no es un nombre","El maximo es 40",nombre,40,2))
        {
            getValidString("\nIngrese el apellido: ","\nApellido no valido","El maximo es 40",apellido,40,2);
            getString("\nIngrese el Cuit del cliente (sin esapacio):  ",cuit);

            retorno = 0;
            strcpy(array[indiceAModificar].nombre,nombre);
            strcpy(array[indiceAModificar].apellido,apellido);
            strcpy(array[indiceAModificar].cuit,cuit);
        }
        else
        {
            retorno = -3;
        }
    }
    return retorno;
}

/** \brief busca un lugar donde isEmpty sea 1, dentro de la esctructura cliente.
 *
 * \param Cliente* array, estructura a buscar lugar libre.
 * \param limite, cantidad de estructuras para buscar.
 * \return int, un valor entero.
 *
 */
static int buscarLugarLibre(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


/** \brief completa el campo id, de la estructura con un valor entero consecutivo.
 *
 * \param void, no se le ingresa valor.
 *
 * \return int, valor entero.
 *
 */
static int proximoId(void)
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}

/** \brief busca por id, dentro de la estructura cliente.
 *
 * \param Cliente* array, estructura a buscar.
 * \param limite, cantidad de estructuras a buscar.
 * \param id, valor por el cual buscar dentro de la estructura.
 * \return int, valor entero.
 *
 */

int cliente_buscarPorId(Cliente* array,int limite, int id)
//static int buscarPorId(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idCliente==id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

/** \brief da el alta de la esctructa cliente, directamente por la funcion, sin tener que pasar por un menu de carga.
 *
 * \param Cliente* array, estructura a completar los campos, pasados por funcion.
 * \param limite, cantidad de estructuras a completar.
 * \param nombre, array de caracteres ingresados por funcion.
 * \param apellido, array de caracteres ingresados por funcion.
 * \param cuit, array de caracteres ingresados por funcion.
 * \return int, valor entero.
 *
 */

int cliente_altaForzada(Cliente* array,int limite,char* nombre,char* apellido, char* cuit)
{
    int retorno = -1;
    int i;

    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre(array,limite);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(array[i].nombre,nombre);
            strcpy(array[i].apellido,apellido);
            strcpy(array[i].cuit,cuit);
            array[i].idCliente = proximoId();
            array[i].isEmpty = 0;
        }
        retorno = 0;
    }
    return retorno;
}

/** \brief muestra los clientes con publicaciones activas.
 *
 * \param Publicacion* array, estructura a buscar estado activo.
 * \param int limite, cantidad de estructuras de publicacion.
 * \param Cliente* arrayC,estructura a buscar en base al id de cliente.
 * \param int limiteC, cantidad de estructuras de clientes
 * \return int, valor entero.
 *
 */

int cliente_soloMostrarActivos(Publicacion* array,int limite, Cliente* arrayC, int limiteC)
{
    int retorno = -1;
    int i;
    int j;
    int acumulador=0;

    if(limite > 0 && limiteC > 0 && array != NULL && arrayC != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteC;i++)
        {
            acumulador=0;

            for(j=0; j < limite; j++)
            {
                if(!(arrayC[i].isEmpty) && !(array[j].isEmpty) && array[j].idCliente == arrayC[i].idCliente && array[j].estadoActivo == 1)
                {
                    acumulador++;
                }
            }
            if(acumulador >= 1 )
            {
              printf("\nNombre : %s.\nApellido: %s.\nCuit: %s\nCantidad de activos: %d\n", arrayC[i].nombre, arrayC[i].apellido, arrayC[i].cuit,acumulador);
            }
        }
    }
    return retorno;
}

/** \brief informa los clientes en base a la cantidad de aviso totales, avisos activos y avisos pausados.
 *
 * \param Cliente* arrayC,estructura a buscar en base al id de cliente.
 * \param int limiteC, cantidad de estructuras de clientes.
 * \param Publicacion* array, estructura a buscar estado activo.
 * \param int limite, cantidad de estructuras de publicacion.
 * \return int, valor entero.
 *
 */

int cliente_informar(Cliente* arrayC, int limiteC, Publicacion* arrayP, int limiteP)
{
    int i,j;
    int acumuladorActivo=0;
    int acumuladorPausado=0;
    int acumuladorTotal=0;
    int maximoA;
    int maximoP;
    int maximoT;
    int flag=1;

    if(limiteC > 0 && limiteP > 0  && arrayC != NULL && arrayP != NULL)
    {
        //--------------------------------//busqueda del mas activo, mas pausado y del total de avisos publicados.
        for(i=0;i <limiteC; i ++)
        {

            acumuladorTotal=0;
            acumuladorActivo=0;
            acumuladorPausado=0;

            for(j = 0;j < limiteP;j ++)
            {
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 1)
                {
                    acumuladorActivo++;
                    acumuladorTotal++;
                }
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 0)
                {
                   acumuladorPausado++;
                   acumuladorTotal++;
                }
            }
            if(flag && acumuladorTotal >=1)
            {
                flag=0;

                maximoA=acumuladorActivo;
                maximoP=acumuladorPausado;
                maximoT=acumuladorTotal;
            }
            if(acumuladorActivo >= maximoA && !flag)
            {
                maximoA=acumuladorActivo;
            }
            if(acumuladorPausado >= maximoP && !flag)
            {
                maximoP=acumuladorPausado;
            }
            if(acumuladorTotal >= maximoT && !flag)
            {
                maximoT=acumuladorTotal;
            }
        }
        //--------------------------// Imprimir los maximos y los totales.
        for(i=0;i <limiteC; i ++)
        {

            acumuladorTotal=0;
            acumuladorActivo=0;
            acumuladorPausado=0;

            for(j = 0;j < limiteP;j ++)
            {
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 1)
                {
                    acumuladorActivo++;
                    acumuladorTotal++;
                }
                if(!(arrayC[i].isEmpty) && !(arrayP[j].isEmpty) && arrayP[j].idCliente == arrayC[i].idCliente && arrayP[j].estadoActivo == 0)
                {
                   acumuladorPausado++;
                   acumuladorTotal++;
                }
            }
            if(acumuladorActivo >= maximoA && !(arrayC[i].isEmpty))
            {
               printf("\nId del cliente con mas aviso activos: ID %d.\nCon la cantidad de avisos activos: %d.\n",arrayC[i].idCliente,maximoA);
            }
            if(acumuladorPausado >= maximoP && !(arrayC[i].isEmpty))
            {
                 printf("\nId del cliente con mas avisos pausados: ID %d.\nCon la cantidad de avisos pausados: %d.\n",arrayC[i].idCliente,maximoP);
            }
            if(acumuladorTotal >= maximoT && !(arrayC[i].isEmpty))
            {
               printf("\nId del cliente con mas avisos (activos + pausados): ID %d.\nCon la cantidad total de avisos: %d.\n",arrayC[i].idCliente,maximoT);
            }
        }
    }
    return 0;
}

