int sumaEnteros(int primerNumero, int segundoNumero, float* resultado);
int restaEnteros(int primerNumero, int segundoNumero, float *resultado);
int multiplicaEnteros(int primerNumero, int segundoNumero, float *resultado);
int divideEnteros(int primerNumero, int segundoNumero, float *resultado);
